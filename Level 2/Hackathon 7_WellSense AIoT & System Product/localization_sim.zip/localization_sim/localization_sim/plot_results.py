from __future__ import annotations

from pathlib import Path
from typing import Sequence

import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

from .estimator import Estimate
from .risk import RiskHeatmapCell
from .room import Room
from .simulator import SimulationRecord


def plot_trajectory(
    room: Room,
    records: Sequence[SimulationRecord],
    estimates: Sequence[Estimate],
    output_path: Path,
) -> None:
    true_x = [r.truth.x_m for r in records]
    true_y = [r.truth.y_m for r in records]
    est_x = [e.x_m for e in estimates]
    est_y = [e.y_m for e in estimates]

    fig, ax = plt.subplots(figsize=(7, 9))
    _draw_room(ax, room, "Simulated indoor coordinate estimate")

    ax.plot(true_x, true_y, label="true path", linewidth=2)
    ax.plot(est_x, est_y, label="estimated path", linestyle="--", linewidth=2)
    ax.scatter([0.5], [0.5], marker="o", label="known start")
    ax.legend(loc="upper right")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(output_path, dpi=160)
    plt.close(fig)


def plot_estimated_track(room: Room, estimates: Sequence[Estimate], output_path: Path) -> None:
    est_x = [e.x_m for e in estimates]
    est_y = [e.y_m for e in estimates]

    fig, ax = plt.subplots(figsize=(7, 9))
    _draw_room(ax, room, "Indoor coordinate estimate")
    ax.plot(est_x, est_y, label="estimated path", linestyle="--", linewidth=2)
    if estimates:
        ax.scatter([est_x[0]], [est_y[0]], marker="o", label="known start")
        ax.scatter([est_x[-1]], [est_y[-1]], marker="x", label="latest estimate")
    ax.legend(loc="upper right")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(output_path, dpi=160)
    plt.close(fig)


def plot_confidence(estimates: Sequence[Estimate], output_path: Path) -> None:
    t_s = [e.time_ms / 1000.0 for e in estimates]
    conf = [e.confidence for e in estimates]

    fig, ax = plt.subplots(figsize=(9, 4))
    ax.set_title("Estimator confidence")
    ax.set_xlabel("time [s]")
    ax.set_ylabel("confidence [0..1]")
    ax.set_ylim(0.0, 1.05)
    ax.grid(True, linestyle="--", linewidth=0.5)
    ax.plot(t_s, conf, linewidth=2)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(output_path, dpi=160)
    plt.close(fig)


def plot_risk_heatmap(room: Room, cells: Sequence[RiskHeatmapCell], output_path: Path) -> None:
    cmap = LinearSegmentedColormap.from_list("wellsense_risk", ["#e9f7ef", "#ffe08a", "#e74c3c"])

    fig, ax = plt.subplots(figsize=(7, 9))
    _draw_room(ax, room, "Gait + location risk heatmap")

    for cell in cells:
        color = cmap(cell.heatmap_score)
        rect = plt.Rectangle(
            (cell.x_min, cell.y_min),
            cell.x_max - cell.x_min,
            cell.y_max - cell.y_min,
            facecolor=color,
            edgecolor="white",
            linewidth=0.4,
            alpha=0.78 if cell.visit_count or cell.gait_window_count else 0.22,
        )
        ax.add_patch(rect)
        if cell.heatmap_score >= 0.33 and (cell.visit_count or cell.gait_window_count):
            ax.text(
                cell.x_center_m,
                cell.y_center_m,
                f"{cell.heatmap_score:.2f}",
                ha="center",
                va="center",
                fontsize=7,
            )

    sm = plt.cm.ScalarMappable(cmap=cmap)
    sm.set_clim(0.0, 1.0)
    cbar = fig.colorbar(sm, ax=ax, fraction=0.046, pad=0.04)
    cbar.set_label("risk score")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(output_path, dpi=160)
    plt.close(fig)


def _draw_room(ax, room: Room, title: str) -> None:
    ax.set_title(title)
    ax.set_xlabel("x [m]")
    ax.set_ylabel("y [m]")
    ax.set_xlim(-0.2, room.width_m + 0.2)
    ax.set_ylim(-0.2, room.height_m + 0.2)
    ax.set_aspect("equal", adjustable="box")
    ax.grid(True, linestyle="--", linewidth=0.5)

    ax.plot([0, room.width_m, room.width_m, 0, 0], [0, 0, room.height_m, room.height_m, 0], linewidth=2)

    gap_left = room.doorway_center_x - room.doorway_width_m / 2.0
    gap_right = room.doorway_center_x + room.doorway_width_m / 2.0
    ax.plot([gap_left, gap_right], [0, 0], linewidth=5)
    ax.text(room.doorway_center_x, -0.15, "doorway", ha="center", va="top")

    for obj in room.objects:
        rect = plt.Rectangle(
            (obj.x_min, obj.y_min),
            obj.x_max - obj.x_min,
            obj.y_max - obj.y_min,
            fill=False,
            linewidth=1.5,
        )
        ax.add_patch(rect)
        cx, cy = obj.center
        ax.text(cx, cy, obj.name, ha="center", va="center", fontsize=8)
